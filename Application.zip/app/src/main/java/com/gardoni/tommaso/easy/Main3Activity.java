package com.gardoni.tommaso.easy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.Switch;

public class Main3Activity extends AppCompatActivity {


    WifiManager wifiManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        setTitle(R.string.act3_name);
        wifiManager = getApplicationContext().getSystemService(WifiManager.class);


    }





















}
