package com.gardoni.tommaso.easy;

import android.Manifest;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.ActionBarContextView;
import android.telephony.CellIdentityCdma;
import android.telephony.CellIdentityGsm;
import android.telephony.CellIdentityLte;
import android.telephony.CellIdentityWcdma;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoWcdma;
import android.telephony.CellLocation;
import android.telephony.CellSignalStrengthCdma;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.CellSignalStrengthWcdma;
import android.telephony.NeighboringCellInfo;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.telephony.TelephonyManager;
import android.telephony.CellInfoLte;
import android.telephony.CellSignalStrengthLte;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    TelephonyManager telephonyManager;
    public static final String TAG = "Problema";
    public Thread thread = null;
    boolean thread_isrunning = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.prova);
        setTitle(R.string.act_name);
        Timestamp time_= new Timestamp(System.currentTimeMillis());
        final String ts= time_.toString();

        final TextView serv_state = findViewById(R.id.s_s);
        final TextView lte_dbm = findViewById(R.id.tw);
        final TextView lte_tac = findViewById(R.id.tw2);
        final TextView lte_cid = findViewById(R.id.tw3);
        final TextView numero_reti = findViewById(R.id.num_nets);
        serv_state.setTextColor(Color.RED);
        lte_dbm.setTextColor(Color.RED);
        lte_tac.setTextColor(Color.RED);
        lte_cid.setTextColor(Color.RED);
        numero_reti.setTextColor(Color.RED);

        Button bottone = findViewById(R.id.button);

        final CheckBox checkBox = findViewById(R.id.checkBox2);
        final CheckBox cb_timer = findViewById(R.id.cb_timer);
        cb_timer.setChecked(true);


        if(checkBox.isChecked()==true)
            generateFile(ts+".txt", "\n"+"Time-Stamp"+ ","+"CID" + "," + "TAC" + "," + "DBM" + "," + "TIM_AD" + "," + "LEVEL" + "," + "PCI" + "," + "MCC" + "," + "MNC" + ","+"Connesso"+"\n");


        cb_timer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d(TAG,"Cambio status");
                if(isChecked){
                    Log.d(TAG,"cbtimer è stato selezionato");
                    //if (thread.isInterrupted()){
                    thread_isrunning=true;
                    //thread.start();
                    Log.d(TAG,"thread avviato");
                    //}


                }
                else{
                    Log.d(TAG,"cbtimer non è stato selezionato");
                    //if (thread.isAlive()){
                    thread.interrupt();
                    thread_isrunning=false;
                    Log.d(TAG,"thread interrotto");
                    // }
                }
            }
        });
        thread = new Thread() {

            @Override
            public void run() {
                while (true) {
                    while (thread_isrunning) {
                        try {
                            Thread.sleep(2000);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d(TAG, "thread attivo");
                                    // Check permission
                                    if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                        // We do not have this permission. Let's ask the user
                                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
                                    } else {
                                        // Get telephony manager
                                        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                                        Log.d("telephonyManager", telephonyManager.toString());
                                    }

                                    int x = 0;
                                    int i = 0;
                                    List<CellInfo> cellInfoList = telephonyManager.getAllCellInfo();
                                    if (cellInfoList != null) {
                                        //for (final CellInfo info : cellInfoList) {
                                        //serv_state.setText(String.valueOf(x) +"//" +String.valueOf(cellInfoList.size()));

                                        for (i = 0; i < cellInfoList.size(); i++) {
                                            CellInfo info = cellInfoList.get(i);


                                            if (info instanceof CellInfoLte) {
                                                x++;
                                                CellSignalStrengthLte strength_lte = ((CellInfoLte) info).getCellSignalStrength();
                                                CellIdentityLte identity_lte = ((CellInfoLte) info).getCellIdentity();

                                                String dbmlte = String.valueOf(strength_lte.getDbm());
                                                String taclte = String.valueOf(identity_lte.getTac());
                                                String cellidentity = String.valueOf(identity_lte.getCi());
                                                String talte = String.valueOf(strength_lte.getTimingAdvance());
                                                String levellte = String.valueOf(strength_lte.getLevel());
                                                String pcilte = String.valueOf(identity_lte.getPci());
                                                String mcclte = String.valueOf(identity_lte.getMcc());
                                                String mnclte = String.valueOf(identity_lte.getMnc());
                                                Timestamp time_= new Timestamp(System.currentTimeMillis());
                                                String ts1= time_.toString();
                                                if(info.isRegistered()==false) {
                                                    lte_dbm.append("\n" + dbmlte);
                                                    lte_tac.append("\n" + "N/A");
                                                    lte_cid.append("\n" + "N/A");



                                                }
                                                else {
                                                    lte_dbm.append("\n" + dbmlte);
                                                    lte_tac.append("\n" + taclte);
                                                    lte_cid.append("\n" + cellidentity);
                                                }
                                                if (checkBox.isChecked() == true) {
                                                    Log.d(TAG,"djjdjdj");
                                                    generateFile(ts + ".txt", time_.toString() + "," + cellidentity + "," + taclte + "," + dbmlte + "," + talte + "," + levellte + "," + pcilte + "," + mcclte + "," + mnclte + "," + String.valueOf(info.isRegistered()) + "\n");
                                                }}


                                        }
                                        serv_state.setText(String.valueOf(x));
                                    }
                                }
                            });
                        } catch (InterruptedException e) {

                            e.printStackTrace();


                        }

                    }
                    try {
                        Log.d(TAG,"stop");
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Log.d(TAG, "Waiting....");
                }
            }
        };
        thread_isrunning = true;
        thread.start();


        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(getApplicationContext(), "Saving infos", Toast.LENGTH_LONG).show();
                }
            }
        });


        bottone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // Check permission
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // We do not have this permission. Let's ask the user
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
                } else {
                    // Get telephony manager
                    telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                    Log.d("telephonyManager", telephonyManager.toString());
                }


                int x = 0;
                int i = 0;
                List<CellInfo> cellInfoList = telephonyManager.getAllCellInfo();
                if (cellInfoList != null) {
                    //for (final CellInfo info : cellInfoList) {


                    for (i = 0; i < cellInfoList.size(); i++) {
                        CellInfo info = cellInfoList.get(i);
                        Log .d(TAG, "sono dentro il cellinfo");
                        if (info instanceof CellInfoLte) {
                            x++;
                            CellSignalStrengthLte strength_lte = ((CellInfoLte) info).getCellSignalStrength();
                            CellIdentityLte identity_lte = ((CellInfoLte) info).getCellIdentity();

                            String dbmlte = String.valueOf(strength_lte.getDbm());
                            String taclte = String.valueOf(identity_lte.getTac());
                            String cellidentity = String.valueOf(identity_lte.getCi());
                            String talte = String.valueOf(strength_lte.getTimingAdvance());
                            String levellte = String.valueOf(strength_lte.getLevel());
                            String pcilte = String.valueOf(identity_lte.getPci());
                            String mcclte = String.valueOf(identity_lte.getMcc());
                            String mnclte = String.valueOf(identity_lte.getMnc());
                            //if ((identity_lte.getTac() != Integer.MAX_VALUE && identity_lte.getCi() != Integer.MAX_VALUE)|| strength_lte.getDbm()!= Integer.MAX_VALUE) {
                            if(info.isRegistered()==false) {
                                lte_dbm.append("\n" + dbmlte);
                                lte_tac.append("\n" + "N/A");
                                lte_cid.append("\n" + "N/A");



                            }
                             else {
                                lte_dbm.append("\n" + dbmlte);
                                lte_tac.append("\n" + taclte);
                                lte_cid.append("\n" + cellidentity);
                            }
                            if (checkBox.isChecked() == true)
                                generateFile(ts+".txt", "\n" + cellidentity + "," + taclte + "," + String.valueOf(info.isRegistered()) + "," + dbmlte + "," + talte + "," + levellte + "," + pcilte + "," + mcclte + "," + mnclte + ";");


                        }
                    }
                    serv_state.setText(String.valueOf(x));
                }
                if (x<=0) {
                    Toast.makeText(getApplicationContext(), "No LTE coverage", Toast.LENGTH_LONG).show();
                }

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();


        switch (id) {
            case R.id.others:
                openActivity2();
                break;
            //case R.id.wifi:
              //  openActivity3();
                //break;
        }


        return true;
    }


    public void openActivity2() {
        Intent intent = new Intent(this, main2Activity.class);
        startActivity(intent);
    }


    public void openActivity3() {
        Intent intent1 = new Intent(this, Main3Activity.class);
        startActivity(intent1);
    }


    //writing data on  text file
    public void generateFile(String sFileName, String sBody) {

        //String s=Environment.getExternalStorageState();
        try {
            File root = new File(Environment.getExternalStorageDirectory(), "My_Cattura");
            if (!root.exists()) {
                root.mkdir();
            }
            File filepath = new File(root, sFileName);
            FileWriter writer = new FileWriter(filepath, true);
            writer.append(sBody);
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 10: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted!
                    // you may now do the action that requires this permission
                    // Get telephony manager
                    telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

                } else {
                    // permission denied
                    return;
                }
            }

        }


    }


}
