package com.gardoni.tommaso.easy;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.CellIdentityGsm;
import android.telephony.CellIdentityLte;
import android.telephony.CellInfo;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;

import android.telephony.CellSignalStrengthLte;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.util.List;

public class main2Activity extends AppCompatActivity {
    TelephonyManager telephonyManager;
    public static final String TAG = "Problema";
    public Thread thread = null;
    boolean thread_isrunning = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prova2);
        setTitle(R.string.act2_name);

        final TextView serv_state= findViewById(R.id.s_s);
        final  TextView lte_ta = findViewById(R.id.tw);
        final  TextView lte_rsrp = findViewById(R.id.tw2);
        final  TextView lte_pci = findViewById(R.id.tw3);
        TextView numero_reti= findViewById(R.id.num_nets);
        Button bottone= findViewById(R.id.button);
        final CheckBox cb_timer = findViewById(R.id.cb_timer);
        cb_timer.setChecked(true);


        cb_timer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d(TAG,"Cambio status");
                if(isChecked){
                    Log.d(TAG,"cbtimer è stato selezionato");
                    //if (thread.isInterrupted()){
                    thread_isrunning=true;
                    //thread.start();
                    Log.d(TAG,"thread avviato");
                    //}


                }
                else{
                    Log.d(TAG,"cbtimer non è stato selezionato");
                    //if (thread.isAlive()){
                    thread.interrupt();
                    thread_isrunning=false;
                    Log.d(TAG,"thread interrotto");
                    // }
                }
            }
        });
        thread = new Thread() {

            @Override
            public void run() {
                while (true) {
                    while (thread_isrunning) {
                        try {
                            Thread.sleep(2000);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d(TAG, "thread attivo");
                                    // Check permission
                                    if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                        // We do not have this permission. Let's ask the user
                                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
                                    } else {
                                        // Get telephony manager
                                        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                                        Log.d("telephonyManager", telephonyManager.toString());
                                    }

                                    int i = 0;
                                    List<CellInfo> cellInfoList = telephonyManager.getAllCellInfo();
                                    if (cellInfoList != null) {

                                        for (i = 0; i < cellInfoList.size(); i++) {
                                            CellInfo info = cellInfoList.get(i);


                                            if (info instanceof CellInfoLte) {
                                                CellSignalStrengthLte strength_lte = ((CellInfoLte) info).getCellSignalStrength();
                                                CellIdentityLte identity_lte= ((CellInfoLte)info).getCellIdentity();

                                                String talte= String.valueOf(identity_lte.getCi() );
                                                String cilte=String.valueOf(identity_lte.getCi());
                                                String pcilte= String.valueOf(identity_lte.getPci());
                                                if(info.isRegistered()==false) {
                                                    lte_ta.append("\n" + "N/A");
                                                    lte_rsrp.append("\n" + "N/A");
                                                    lte_pci.append("\n" + pcilte);
                                                    serv_state.append("\n"+String.valueOf(info.isRegistered()));



                                                }
                                                else {
                                                    lte_ta.append("\n" + "N/A");
                                                    lte_rsrp.append("\n" + cilte);
                                                    lte_pci.append("\n" + pcilte);
                                                    serv_state.append("\n" + String.valueOf(info.isRegistered()));
                                                }
                                                }


                                        }
                                    }
                                }
                            });
                        } catch (InterruptedException e) {

                            e.printStackTrace();


                        }

                    }
                    try {
                        Log.d(TAG,"stop");
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Log.d(TAG, "Waiting....");
                }
            }
        };
        thread_isrunning = true;
        thread.start();



        bottone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Check permission
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // We do not have this permission. Let's ask the user
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 10);
                }
                else {
                    // Get telephony manager
                    telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                    Log.d("telephonyManager", telephonyManager.toString());
                }
                int x=0;
                int i=0;
                List<CellInfo> cellInfoList = telephonyManager.getAllCellInfo();
                if (cellInfoList != null) {


                    for(i=0;i<cellInfoList.size();i++){
                        CellInfo info=cellInfoList.get(i);
                        if (info instanceof CellInfoLte) {
                            x++;
                            CellSignalStrengthLte strength_lte = ((CellInfoLte) info).getCellSignalStrength();
                            CellIdentityLte identity_lte= ((CellInfoLte)info).getCellIdentity();

                            String talte= String.valueOf(identity_lte.getCi() );
                            String cilte=String.valueOf(identity_lte.getCi());
                            String pcilte= String.valueOf(identity_lte.getPci());
                            if(info.isRegistered()==false) {
                                lte_ta.append("\n" + "N/A");
                                lte_rsrp.append("\n" + "N/A");
                                lte_pci.append("\n" + pcilte);
                                serv_state.append("\n"+String.valueOf(info.isRegistered()));



                            }
                            else {
                                lte_ta.append("\n" + "N/A");
                                lte_rsrp.append("\n" + cilte);
                                lte_pci.append("\n" + pcilte);
                                serv_state.append("\n" + String.valueOf(info.isRegistered()));
                            }

                        }
                    }
                }
                if (x<=0) {
                    Toast.makeText(getApplicationContext(), "No LTE coverage", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult ( int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 10: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted!
                    // you may now do the action that requires this permission
                    // Get telephony manager
                    telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

                } else {
                    // permission denied
                    return;
                }
            }
        }
    }
}
